package br.com.etechoracio.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pw2JpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
